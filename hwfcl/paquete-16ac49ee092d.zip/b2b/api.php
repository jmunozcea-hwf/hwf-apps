<?php
/**
 * Puente del portal B2B «Clientes HWF» (https://www.hwf.cl/b2b/).
 *
 * El navegador manda JSON {accion, token?, ...} (la contraseña del cliente va en `pass`).
 * Este archivo valida, agrega la clave del script (solo en config.php, en el servidor)
 * y reenvía al script de Google. La respuesta del script se devuelve tal cual.
 * Ver CONTRATO.md. Requiere PHP 7.4+. Usa cURL si existe; si no, file_get_contents.
 */

ini_set('display_errors', '0');
ob_start();

const B2B_MAX_BYTES = 65536;
const B2B_MAX_POSTULAR = 6291456; // «Trabaja con nosotros» (23-11-2026): la postulación trae el CV (hasta 4 MB → ~5,4 MB en base64)
const B2B_RL_MAX = 10;
const B2B_RL_VENTANA = 900; // 15 minutos, en segundos
const B2B_ACCIONES = [
    'b2bRegistro', 'b2bLogin', 'b2bSalir', 'b2bCatalogo', 'b2bPedido', 'b2bMisPedidos',
    'b2bCobranza', 'b2bFidelidad', 'b2bCanje', 'b2bContenido',
    'webEvento', // navegación con cookies de analítica aceptadas (23-11-2026): lotes de eventos anónimos
    'webVisita', // contador de visitas de hwf.cl y del portal (22-11-2026): sin cookies ni datos personales
    'b2bKit', 'kitValidar', // Kit para tu local (22-11-2026)
    'b2bCambiarClave', // cambio de clave cada 3 meses (22-11-2026)
    'postular', // «Trabaja con nosotros» de hwf.cl (23-11-2026)
];
const B2B_ACCIONES_LIMITADAS = ['b2bLogin', 'b2bRegistro', 'kitValidar', 'b2bCambiarClave', 'postular'];

/** Devuelve el cuerpo tal cual con las cabeceras de seguridad. */
function b2b_salida($codigo, $cuerpo)
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code($codigo);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    echo $cuerpo;
    exit;
}

function b2b_error($codigo, $mensaje)
{
    $json = json_encode(['ok' => false, 'error' => $mensaje], JSON_UNESCAPED_UNICODE);
    b2b_salida($codigo, $json !== false ? $json : '{"ok":false}');
}

/** Lee config.php. Devuelve null si falta o no está completo. */
function b2b_config()
{
    $ruta = __DIR__ . '/config.php';
    if (!is_file($ruta)) {
        return null;
    }
    $cfg = include $ruta;
    if (!is_array($cfg) || empty($cfg['script_url']) || empty($cfg['clave'])
        || !is_string($cfg['script_url']) || !is_string($cfg['clave'])) {
        return null;
    }
    // Solo se acepta el script de Google por HTTPS.
    $esquema = parse_url($cfg['script_url'], PHP_URL_SCHEME);
    $host = parse_url($cfg['script_url'], PHP_URL_HOST);
    if ($esquema !== 'https' || $host !== 'script.google.com') {
        return null;
    }
    return $cfg;
}

function b2b_ip()
{
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    return $ip !== '' ? $ip : 'desconocida';
}

/**
 * Límite de intentos por IP (guardado con hash HMAC, no con la IP a la vista).
 * Devuelve 0 = permitido, 1 = exceso, 2 = no se pudo verificar.
 */
function b2b_rate_limitar($ip, $sal)
{
    $llave = hash_hmac('sha256', $ip, $sal);
    $ruta = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'hwf_b2b_rl.json';
    $f = @fopen($ruta, 'c+');
    if ($f === false) {
        return 2;
    }
    if (!flock($f, LOCK_EX)) {
        fclose($f);
        return 2;
    }
    $mapa = json_decode((string)stream_get_contents($f), true);
    if (!is_array($mapa)) {
        $mapa = [];
    }
    $ahora = time();
    foreach ($mapa as $k => $marcas) {
        $vigentes = [];
        foreach ((array)$marcas as $t) {
            if (is_int($t) && $t > $ahora - B2B_RL_VENTANA) {
                $vigentes[] = $t;
            }
        }
        if (count($vigentes) === 0) {
            unset($mapa[$k]);
        } else {
            $mapa[$k] = $vigentes;
        }
    }
    $marcas = $mapa[$llave] ?? [];
    $resultado = 0;
    if (count($marcas) >= B2B_RL_MAX) {
        $resultado = 1;
    } else {
        $marcas[] = $ahora;
        $mapa[$llave] = $marcas;
    }
    ftruncate($f, 0);
    rewind($f);
    fwrite($f, json_encode($mapa));
    fflush($f);
    flock($f, LOCK_UN);
    fclose($f);
    return $resultado;
}

/** Reenvía el JSON al script. Devuelve el cuerpo de la respuesta o null si falla. */
function b2b_enviar($url, $json)
{
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        if ($ch === false) {
            return null;
        }
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $json,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true, // Apps Script responde 302 y luego entrega el resultado
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        if (defined('CURLOPT_REDIR_PROTOCOLS') && defined('CURLPROTO_HTTPS')) {
            curl_setopt($ch, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTPS);
        }
        $cuerpo = curl_exec($ch);
        $errno = curl_errno($ch);
        curl_close($ch);
        if ($cuerpo === false || $errno !== 0) {
            error_log('B2B puente: fallo cURL (' . $errno . ')');
            return null;
        }
        return (string)$cuerpo;
    }

    $ctx = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/json\r\nAccept: application/json\r\n",
            'content' => $json,
            'timeout' => 30,
            'follow_location' => 1,
            'max_redirects' => 5,
            'ignore_errors' => true,
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);
    $cuerpo = @file_get_contents($url, false, $ctx);
    return $cuerpo === false ? null : (string)$cuerpo;
}

function b2b_principal()
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        header('Allow: POST');
        b2b_error(405, 'Método no permitido.');
    }

    // Solo mismo origen: si el navegador manda Origin, debe ser el host del sitio.
    if (!empty($_SERVER['HTTP_ORIGIN'])) {
        $oHost = parse_url((string)$_SERVER['HTTP_ORIGIN'], PHP_URL_HOST);
        $hHost = strtolower(preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
        if (!is_string($oHost) || strtolower($oHost) !== $hHost) {
            b2b_error(403, 'Origen no permitido.');
        }
    }

    $tipo = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
    if (!preg_match('~^application/json\s*(;|$)~', $tipo)) {
        b2b_error(415, 'Formato no válido. Envía JSON.');
    }

    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > B2B_MAX_POSTULAR) {
        b2b_error(413, 'Solicitud demasiado grande.');
    }
    $raw = file_get_contents('php://input', false, null, 0, B2B_MAX_POSTULAR + 1);
    if ($raw === false) {
        b2b_error(400, 'Solicitud no válida.');
    }
    if (strlen($raw) > B2B_MAX_POSTULAR) {
        b2b_error(413, 'El archivo es demasiado grande (máximo 4 MB).');
    }
    // solo la postulación (con CV) puede pasar de 64 KB; se revisa antes de decodificar el JSON
    if (strlen($raw) > B2B_MAX_BYTES && !preg_match('~^\s*\{\s*"accion"\s*:\s*"postular"~', $raw)) {
        b2b_error(413, 'Solicitud demasiado grande.');
    }

    $datos = json_decode($raw, true, 16);
    if (!is_array($datos)) {
        b2b_error(400, 'Solicitud no válida.');
    }
    $accion = (isset($datos['accion']) && is_string($datos['accion'])) ? $datos['accion'] : '';
    if (!in_array($accion, B2B_ACCIONES, true)) {
        b2b_error(400, 'Acción no permitida.');
    }

    $cfg = b2b_config();
    if ($cfg === null) {
        b2b_error(503, 'Portal no configurado');
    }

    $ip = b2b_ip();
    if (in_array($accion, B2B_ACCIONES_LIMITADAS, true)) {
        $r = b2b_rate_limitar($ip, (string)$cfg['clave']);
        if ($r === 1) {
            b2b_error(429, 'Demasiados intentos. Espera unos minutos.');
        }
        if ($r === 2) {
            b2b_error(503, 'Servicio temporalmente no disponible. Intenta más tarde.');
        }
    }

    // Lo que mande el navegador para estos campos se descarta; los pone el servidor.
    // La contraseña del cliente viaja en `pass` y se reenvía tal cual.
    unset($datos['clave'], $datos['origen'], $datos['ip']);
    $datos['origen'] = 'b2b';
    $datos['ip'] = $ip;
    $datos['clave'] = (string)$cfg['clave'];

    $json = json_encode($datos, JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        b2b_error(400, 'Solicitud no válida.');
    }

    $msgFallo = 'El servidor de HWF no respondió. Intenta de nuevo.';
    /* b2bContenido es público e igual para todos: se guarda 2 minutos en el hosting (la página y el portal cargan al instante);
       si el script no responde, se usa la última copia buena (hasta 1 día). */
    $cacheF = ($accion === 'b2bContenido') ? rtrim(sys_get_temp_dir(), '/') . '/hwf_b2b_contenido_' . substr(hash('sha256', (string)$cfg['script_url']), 0, 12) . '.json' : '';
    if ($cacheF !== '' && is_file($cacheF) && time() - (int)@filemtime($cacheF) < 120) {
        $c = @file_get_contents($cacheF);
        if (is_string($c) && $c !== '') { b2b_salida(200, $c); }
    }
    $resp = b2b_enviar((string)$cfg['script_url'], $json);
    if ($cacheF !== '') {
        $j = $resp === null ? null : json_decode($resp, true);
        if (is_array($j) && !empty($j['ok'])) { @file_put_contents($cacheF . '.tmp', $resp, LOCK_EX); @rename($cacheF . '.tmp', $cacheF); }
        elseif (is_file($cacheF) && time() - (int)@filemtime($cacheF) < 86400) { $c = @file_get_contents($cacheF); if (is_string($c) && $c !== '') { b2b_salida(200, $c); } }
    }
    if ($resp === null) {
        b2b_error(502, $msgFallo);
    }
    $respuesta = json_decode($resp, true);
    if (!is_array($respuesta)) {
        b2b_error(502, $msgFallo);
    }
    // Se devuelve tal cual lo entregó el script.
    b2b_salida(200, $resp);
}

try {
    b2b_principal();
} catch (Throwable $e) {
    error_log('B2B puente: error interno');
    b2b_error(500, 'Error interno del portal. Intenta de nuevo.');
}
