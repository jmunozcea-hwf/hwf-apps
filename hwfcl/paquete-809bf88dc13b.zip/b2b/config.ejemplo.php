<?php
/*
 * Plantilla de configuración del portal B2B. NO lleva datos reales.
 *
 * Para usarla: copia este archivo con el nombre config.php (en la misma carpeta b2b)
 * y reemplaza los valores vacíos:
 *   'script_url' → la URL de la aplicación web del script de Google (empieza con https://script.google.com/macros/s/)
 *   'clave'      → la misma clave que usan las apps Ventas y HWF Admin
 *   'mail_secreto' → (mailing) el MISMO texto largo que MAIL_SECRETO en Config.gs del script (40+ caracteres al azar)
 *   'mail_desde'   → (mailing) casilla remitente creada en cPanel → Correo, p. ej. noticias@hwf.cl
 *   'wa_token', 'wa_phone_id', 'wa_verify', 'wa_app_secret' → (WhatsApp del asistente IA, whatsapp.php) token permanente,
 *     id del número, texto de verificación inventado y App Secret de la app de Meta (ver entrega/agente/WHATSAPP.md)
 *   'actualizar_token' → (actualizador de hwf.cl) texto largo al azar, 32+ caracteres; el mismo del secreto X-Hwf-Token del entorno de Claude
 *
 * config.php nunca se sube al repositorio público ni se publica en la web.
 */
return [
    'script_url' => '',
    'clave' => '',
    'mail_secreto' => '',
    'mail_desde' => 'noticias@hwf.cl',
    'actualizar_token' => '',
    'wa_token' => '',
    'wa_phone_id' => '',
    'wa_verify' => '',
    'wa_app_secret' => '',
    'wa_phone_id_tienda' => '', // opcional: id del número de WhatsApp de la Tienda Hellywoof (claudIA para clientes finales)
];
