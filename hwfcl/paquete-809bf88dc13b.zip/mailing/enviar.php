<?php
/*
 * Mailing HWF · recibe tandas del script de Google y las envía con mail() del hosting.
 * POST JSON {ts, desde, nombre, responder, mensajes:[{para, asunto, html, texto, baja, responder}]}
 * Cabecera X-Firma = HMAC-SHA256(cuerpo, mail_secreto) en hex. Marca de tiempo válida ±10 min. Máx. 50 mensajes por tanda.
 * Responde {ok:true, resultados:[{ok, error?}]}.
 */
declare(strict_types=1);
require __DIR__ . '/comun.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { mail_json(405, ['ok' => false, 'error' => 'Método no permitido.']); exit; }
$cfg = mail_config();
if ($cfg === null) { mail_json(503, ['ok' => false, 'error' => 'Mailing no configurado en hwf.cl.']); exit; }
$cuerpo = (string)file_get_contents('php://input', false, null, 0, 4 * 1024 * 1024 + 1);
if (strlen($cuerpo) > 4 * 1024 * 1024) { mail_json(413, ['ok' => false, 'error' => 'Tanda demasiado grande.']); exit; }
$firma = (string)($_SERVER['HTTP_X_FIRMA'] ?? '');
if ($firma === '' || !hash_equals(hash_hmac('sha256', $cuerpo, $cfg['mail_secreto']), $firma)) { mail_json(403, ['ok' => false, 'error' => 'Firma inválida.']); exit; }
$d = json_decode($cuerpo, true);
if (!is_array($d) || !isset($d['ts'], $d['mensajes']) || !is_array($d['mensajes'])) { mail_json(400, ['ok' => false, 'error' => 'Tanda inválida.']); exit; }
if (abs(time() * 1000 - (int)$d['ts']) > 600000) { mail_json(403, ['ok' => false, 'error' => 'Tanda vencida.']); exit; }
if (count($d['mensajes']) > 50) { mail_json(400, ['ok' => false, 'error' => 'Máximo 50 mensajes por tanda.']); exit; }

$desde = (string)($cfg['mail_desde'] ?? 'noticias@hwf.cl');
if (!mail_correo_ok($desde)) { mail_json(500, ['ok' => false, 'error' => 'Remitente inválido en config.php.']); exit; }
$nombre = preg_replace('/[^\p{L}\p{N} .,&-]/u', '', (string)($d['nombre'] ?? 'HWF')) ?: 'HWF';
$responder0 = (string)($d['responder'] ?? '');

$cab = static function (string $s): string {   // cabecera UTF-8 (RFC 2047)
    return '=?UTF-8?B?' . base64_encode($s) . '?=';
};
$resultados = [];
foreach ($d['mensajes'] as $m) {
    $para = trim((string)($m['para'] ?? ''));
    $asunto = str_replace(["\r", "\n"], ' ', (string)($m['asunto'] ?? ''));
    $html = (string)($m['html'] ?? '');
    $texto = (string)($m['texto'] ?? '');
    $baja = (string)($m['baja'] ?? '');
    $resp = (string)($m['responder'] ?? '') ?: $responder0;
    if (!mail_correo_ok($para) || $asunto === '' || $html === '' || strpos($baja, 'https://') !== 0 || preg_match('/[\r\n]/', $baja)) {
        $resultados[] = ['ok' => false, 'error' => 'Mensaje inválido.'];
        continue;
    }
    $limite = 'hwf' . bin2hex(random_bytes(12));
    $h = [];
    $h[] = 'From: ' . $cab($nombre) . ' <' . $desde . '>';
    if ($resp !== '' && mail_correo_ok($resp)) { $h[] = 'Reply-To: ' . $resp; }
    $h[] = 'MIME-Version: 1.0';
    $h[] = 'Content-Type: multipart/alternative; boundary="' . $limite . '"';
    $h[] = 'List-Unsubscribe: <' . $baja . '>, <mailto:' . $desde . '?subject=baja>';
    $h[] = 'List-Unsubscribe-Post: List-Unsubscribe=One-Click';
    $h[] = 'X-Mailer: HWF Mailing';
    $msj = '--' . $limite . "\r\n" . "Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($texto)) .
        '--' . $limite . "\r\n" . "Content-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($html)) .
        '--' . $limite . "--\r\n";
    $ok = @mail($para, $cab($asunto), $msj, implode("\r\n", $h), '-f' . $desde);
    $resultados[] = $ok ? ['ok' => true] : ['ok' => false, 'error' => 'El servidor de correo rechazó el envío.'];
}
mail_json(200, ['ok' => true, 'resultados' => $resultados]);
