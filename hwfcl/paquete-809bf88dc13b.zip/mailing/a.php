<?php
/* Mailing HWF · píxel de apertura (1×1 GIF). Firma: mail_firma_corta(secreto, c, e, "abre"). Nunca falla hacia el lector. */
declare(strict_types=1);
require __DIR__ . '/comun.php';
header('Content-Type: image/gif');
header('Cache-Control: no-store, max-age=0');
echo base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
mail_soltar();
$cfg = mail_config();
$c = substr((string)($_GET['c'] ?? ''), 0, 40);
$e = strtolower(trim(substr((string)($_GET['e'] ?? ''), 0, 254)));
$s = (string)($_GET['s'] ?? '');
if ($cfg !== null && mail_correo_ok($e) && hash_equals(mail_firma_corta($cfg['mail_secreto'], $c, $e, 'abre'), $s)) {
    mail_evento($cfg, ['c' => $c, 'e' => $e, 'tipo' => 'abre', 's' => $s]);
}
