<?php
/*
 * Mailing HWF · funciones comunes (contrato: CONTRATO.md).
 * Lee la MISMA configuración del portal B2B: ../b2b/config.php
 *   'script_url'   URL del script de Google (https://script.google.com/macros/s/…)
 *   'clave'        clave de las apps
 *   'mail_secreto' secreto compartido con el script (MAIL_SECRETO en Config.gs) para firmar tandas y enlaces
 *   'mail_desde'   (opcional) casilla remitente; por defecto noticias@hwf.cl (debe existir en el cPanel de hwf.cl)
 * config.php nunca va al repositorio.
 */
declare(strict_types=1);

const MAIL_DOMINIOS_OK = ['hwf.cl', 'www.hwf.cl', 'wa.me', 'jmunozcea-hwf.github.io'];

function mail_config(): ?array
{
    $ruta = dirname(__DIR__) . '/b2b/config.php';
    if (!is_file($ruta)) {
        return null;
    }
    $cfg = include $ruta;
    if (!is_array($cfg) || empty($cfg['mail_secreto']) || !is_string($cfg['mail_secreto']) || strlen($cfg['mail_secreto']) < 24) {
        return null;
    }
    return $cfg;
}

/** Firma corta de enlaces: igual a mailFirmaCorta_ del script (HMAC-SHA256 de "c|e|x", 32 hex). */
function mail_firma_corta(string $secreto, string ...$partes): string
{
    return substr(hash_hmac('sha256', implode('|', $partes), $secreto), 0, 32);
}

function mail_json(int $codigo, array $o): void
{
    http_response_code($codigo);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    echo json_encode($o, JSON_UNESCAPED_UNICODE);
}

/** Avisa un evento (abre, clic, baja) al script; corto y sin romper la respuesta al navegador. */
function mail_evento(array $cfg, array $ev): bool
{
    if (empty($cfg['script_url']) || empty($cfg['clave'])) {
        return false;
    }
    if (parse_url((string)$cfg['script_url'], PHP_URL_SCHEME) !== 'https' || parse_url((string)$cfg['script_url'], PHP_URL_HOST) !== 'script.google.com') {
        return false;
    }
    $json = json_encode(array_merge($ev, ['accion' => 'mailEvento', 'clave' => $cfg['clave'], 'origen' => 'mail']), JSON_UNESCAPED_UNICODE);
    if (!function_exists('curl_init')) {
        $ctx = stream_context_create(['http' => ['method' => 'POST', 'header' => "Content-Type: application/json\r\n", 'content' => $json, 'timeout' => 15, 'follow_location' => 1, 'ignore_errors' => true]]);
        $r = @file_get_contents((string)$cfg['script_url'], false, $ctx);
        return $r !== false && strpos((string)$r, '"ok":true') !== false;
    }
    $ch = curl_init((string)$cfg['script_url']);
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_POSTFIELDS => $json, CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 5,
        CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $r = curl_exec($ch);
    curl_close($ch);
    return is_string($r) && strpos($r, '"ok":true') !== false;
}

/** Correo válido y sin saltos de línea (evita inyección de cabeceras). */
function mail_correo_ok(string $e): bool
{
    return strlen($e) <= 254 && !preg_match('/[\r\n]/', $e) && filter_var($e, FILTER_VALIDATE_EMAIL) !== false;
}

/** Cierra la respuesta al navegador antes de seguir trabajando (si el servidor lo permite). */
function mail_soltar(): void
{
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        @ob_end_flush();
        @flush();
    }
}
