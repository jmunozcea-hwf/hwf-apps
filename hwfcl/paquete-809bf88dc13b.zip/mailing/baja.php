<?php
/*
 * Mailing HWF · baja de un clic. GET muestra la confirmación; POST (botón o List-Unsubscribe-Post de Gmail/Outlook) da de baja.
 * Enlace firmado: ?c=campaña&e=correo&s=firma (mail_firma_corta(secreto, c, e, "baja")).
 */
declare(strict_types=1);
require __DIR__ . '/comun.php';
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');
header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'");
$cfg = mail_config();
$c = substr((string)($_GET['c'] ?? ''), 0, 40);
$e = strtolower(trim(substr((string)($_GET['e'] ?? ''), 0, 254)));
$s = (string)($_GET['s'] ?? '');
$valido = $cfg !== null && mail_correo_ok($e) && hash_equals(mail_firma_corta($cfg['mail_secreto'], $c, $e, 'baja'), $s);
$hecho = false;
if ($valido && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $hecho = mail_evento($cfg, ['c' => $c, 'e' => $e, 'tipo' => 'baja', 's' => $s]);
    if (($_POST['List-Unsubscribe'] ?? '') === 'One-Click') { http_response_code($hecho ? 200 : 502); echo $hecho ? 'OK' : 'ERROR'; exit; }
}
$h = static fn(string $t): string => htmlspecialchars($t, ENT_QUOTES, 'UTF-8');
?><!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">
<title>HWF · Correos</title><style>body{margin:0;font-family:Arial,sans-serif;background:#EEF2F5;color:#0F1E29}main{max-width:460px;margin:40px auto;background:#fff;border-radius:14px;overflow:hidden}
header{background:#0B3146;color:#fff;padding:18px 22px;border-bottom:4px solid #80C6C9;font-size:20px;font-weight:bold}div{padding:22px}button{background:#0B3146;color:#fff;border:0;border-radius:10px;padding:12px 18px;font-size:15px;font-weight:bold;cursor:pointer}a{color:#0B3146}</style></head>
<body><main><header>HWF</header><div>
<?php if (!$valido): ?>
<p>El enlace no es válido o está incompleto. Si quieres dejar de recibir correos de HWF, escríbenos a <a href="mailto:ventas@hwf.cl">ventas@hwf.cl</a>.</p>
<?php elseif ($hecho): ?>
<p><b>Listo.</b> <?= $h($e) ?> ya no recibirá correos de novedades de HWF.</p><p>Los documentos de tus compras (notas de pedido, facturas) siguen llegando normalmente.</p>
<?php elseif (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST'): ?>
<p>No pudimos registrar la baja en este momento. Intenta de nuevo en unos minutos o escríbenos a <a href="mailto:ventas@hwf.cl">ventas@hwf.cl</a>.</p>
<?php else: ?>
<p>¿Quieres que <b><?= $h($e) ?></b> deje de recibir los correos de novedades y promociones de HWF?</p>
<form method="post"><button type="submit">Sí, no quiero recibir más correos</button></form>
<?php endif; ?>
</div></main></body></html>
