<?php
/* Mailing HWF · registra el clic y redirige. Solo a dominios de HWF (lista MAIL_DOMINIOS_OK) y con firma
   mail_firma_corta(secreto, c, e, u): no es un redirector abierto. */
declare(strict_types=1);
require __DIR__ . '/comun.php';
$cfg = mail_config();
$c = substr((string)($_GET['c'] ?? ''), 0, 40);
$e = strtolower(trim(substr((string)($_GET['e'] ?? ''), 0, 254)));
$u = (string)($_GET['u'] ?? '');
$s = (string)($_GET['s'] ?? '');
$host = strtolower((string)parse_url($u, PHP_URL_HOST));
$destino = 'https://www.hwf.cl/';
if ($cfg !== null && parse_url($u, PHP_URL_SCHEME) === 'https' && in_array($host, MAIL_DOMINIOS_OK, true) && !preg_match('/[\r\n]/', $u)
    && hash_equals(mail_firma_corta($cfg['mail_secreto'], $c, $e, $u), $s)) {
    $destino = $u;
    header('Location: ' . $destino, true, 302);
    header('Cache-Control: no-store');
    mail_soltar();
    if (mail_correo_ok($e)) { mail_evento($cfg, ['c' => $c, 'e' => $e, 'tipo' => 'clic', 'u' => $u, 's' => $s]); }
    exit;
}
header('Location: ' . $destino, true, 302);
