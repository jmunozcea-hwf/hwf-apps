/* Cookies de hwf.cl (23-11-2026): aviso, aceptación y preferencias.
   Categorías: necesarias (siempre activas: guardan esta elección y el funcionamiento del portal), analítica (contador de visitas
   anónimo, sin datos personales) y marketing (redes sociales; hoy no se usa ninguna, queda lista para el futuro).
   La elección se guarda 180 días en la cookie «hwf_cookies» (v1.a{0|1}.m{0|1}.<fecha>.<id>). Mientras no haya aceptación de la
   analítica, las llamadas al contador de visitas (accion «webVisita») quedan en espera y se envían solo si la persona acepta.
   API: hwfCookies.estado() · hwfCookies.cuando("analitica"|"marketing", fn) · hwfCookies.abrir() · enlaces con [data-cookies]. */
(function () {
  if (window.hwfCookies) return;
  const NOM = "hwf_cookies", DIAS = 180, VER = "v1";
  const leer = () => { const m = document.cookie.match(/(?:^|;\s*)hwf_cookies=([^;]+)/); if (!m) return null; const p = decodeURIComponent(m[1]).split(".");
    return p[0] === VER ? { analitica: p[1] === "a1", marketing: p[2] === "m1", fecha: p[3] || "", id: p[4] || "" } : null; };
  let E = leer(); const esperando = [], subs = { analitica: [], marketing: [] };
  const guardar = (a, m) => { const id = (E && E.id) || Math.random().toString(36).slice(2, 10), f = new Date().toISOString().slice(0, 10);
    document.cookie = NOM + "=" + encodeURIComponent([VER, a ? "a1" : "a0", m ? "m1" : "m0", f, id].join(".")) + ";max-age=" + DIAS * 86400 + ";path=/;samesite=lax" + (location.protocol === "https:" ? ";secure" : "");
    E = { analitica: a, marketing: m, fecha: f, id };
    /* registro anónimo de la decisión (cuenta en Métricas web: /cookies/…) */
    try { _f("/b2b/api.php", { method: "POST", headers: { "Content-Type": "application/json" }, keepalive: true, body: JSON.stringify({ accion: "webVisita", s: "web", p: "/cookies/" + (a && m ? "todas" : a ? "analitica" : m ? "marketing" : "necesarias"), d: /Mobi|Android|iPhone/i.test(navigator.userAgent) ? "m" : "p", o: "", n: 0 }) }).catch(() => {}); } catch (e) {}
    if (a) setTimeout(() => enviar(), 50); else COLA.length = 0;
    if (a) { esperando.splice(0).forEach(x => _f.apply(window, x).catch(() => {})); subs.analitica.splice(0).forEach(fn => { try { fn(); } catch (e) {} }); } else esperando.length = 0;
    if (m) subs.marketing.splice(0).forEach(fn => { try { fn(); } catch (e) {} }); };
  /* contador de visitas: solo con aceptación de analítica */
  const _f = window.fetch.bind(window);
  window.fetch = function (u, o) { try { const b = o && typeof o.body === "string" ? o.body : ""; if (b.indexOf('"accion":"webVisita"') >= 0 && b.indexOf('"p":"/cookies/') < 0) {
      if (!E) { esperando.push([u, o]); return Promise.resolve(new Response('{"ok":true,"espera":true}', { headers: { "Content-Type": "application/json" } })); }
      if (!E.analitica) return Promise.resolve(new Response('{"ok":true,"omitida":true}', { headers: { "Content-Type": "application/json" } })); } } catch (e) {}
    return _f(u, o); };
  const CSS = `#hwfCk{position:fixed;left:12px;right:12px;bottom:12px;z-index:2147483000;max-width:760px;margin:0 auto;background:#fff;color:#0F1E29;border-radius:18px;box-shadow:0 18px 50px rgba(11,49,70,.28);border:1px solid #D9E2EA;padding:18px;font:15px/1.5 Inter,Arial,sans-serif}
#hwfCk h2{font:900 1.15rem Nunito,Arial,sans-serif;color:#0B3146;margin:0 0 6px}#hwfCk p{margin:0;color:#3E5868;font-size:.92rem}#hwfCk a{color:#1F6A6E;font-weight:600}
#hwfCk .b{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}#hwfCk button{font:700 .95rem Inter,Arial,sans-serif;border-radius:999px;padding:11px 18px;min-height:44px;cursor:pointer;border:1.5px solid #0B3146;background:#fff;color:#0B3146;flex:1 1 auto}
#hwfCk button.p{background:#0B3146;color:#fff}#hwfCk button.t{border-color:transparent;text-decoration:underline;flex:0 1 auto}
#hwfCk .c{display:none;margin-top:12px;border-top:1px solid #E3E9EE;padding-top:8px}#hwfCk.cfg .c{display:block}#hwfCk.cfg .b .t{display:none}
#hwfCk label{display:flex;gap:12px;align-items:flex-start;padding:10px 0;border-bottom:1px solid #EEF2F5;cursor:pointer}#hwfCk label:last-child{border-bottom:0}
#hwfCk label b{display:block;color:#0B3146}#hwfCk label small{color:#5B6874;font-size:.82rem}#hwfCk input{width:22px;height:22px;flex:none;margin-top:2px;accent-color:#0B3146}
@media(min-width:700px){#hwfCk{padding:22px 24px;bottom:20px}#hwfCk button{flex:0 1 auto}}@media(prefers-color-scheme:dark){#hwfCk{border-color:#2A4556}}`;
  function abrir(cfg) { let d = document.getElementById("hwfCk"); if (d) d.remove();
    if (!document.getElementById("hwfCkS")) { const s = document.createElement("style"); s.id = "hwfCkS"; s.textContent = CSS; document.head.appendChild(s); }
    d = document.createElement("div"); d.id = "hwfCk"; d.setAttribute("role", "dialog"); d.setAttribute("aria-live", "polite"); d.setAttribute("aria-label", "Preferencias de cookies"); if (cfg) d.className = "cfg";
    d.innerHTML = `<h2>🍪 Usamos cookies</h2><p>Usamos cookies necesarias para que el sitio y el portal funcionen. Con tu permiso, también contamos visitas de forma anónima para mejorar la página. Puedes cambiar tu elección cuando quieras en «Cookies» al pie de la página. <a href="/privacidad/#cookies">Más información</a></p>
      <div class="c"><label><input type="checkbox" checked disabled><span><b>Necesarias</b><small>Guardan tu elección de cookies, tu sesión en Acceso Clientes y tu lista de pedido. Siempre activas.</small></span></label>
        <label><input type="checkbox" id="hwfCkA" ${E && E.analitica ? "checked" : ""}><span><b>Analítica</b><small>Cuenta visitas por página y tipo de dispositivo, sin datos personales.</small></span></label>
        <label><input type="checkbox" id="hwfCkM" ${E && E.marketing ? "checked" : ""}><span><b>Marketing</b><small>Para medir campañas en redes sociales (Instagram, Facebook, LinkedIn). Hoy no se usa ninguna.</small></span></label></div>
      <div class="b"><button type="button" class="p" data-ck="todas">Aceptar todas</button><button type="button" data-ck="nec">Solo necesarias</button><button type="button" class="t" data-ck="cfg">Configurar</button><button type="button" class="p" data-ck="guardar" style="display:none">Guardar mi elección</button></div>`;
    document.body.appendChild(d);
    const g = d.querySelector('[data-ck="guardar"]'); if (cfg) g.style.display = "";
    d.onclick = e => { const b = e.target.closest("[data-ck]"); if (!b) return; const k = b.dataset.ck;
      if (k === "cfg") { d.classList.add("cfg"); g.style.display = ""; return; }
      if (k === "todas") guardar(true, true); else if (k === "nec") guardar(false, false); else guardar(d.querySelector("#hwfCkA").checked, d.querySelector("#hwfCkM").checked);
      d.remove(); }; }
  /* ===== navegación (solo con analítica aceptada, 23-11-2026): sesiones, visitante anónimo (id de la cookie), tiempo, lectura,
     clics en botones clave y, en el portal, el embudo (ingreso → búsqueda → carrito → pedido). Se envía en lotes a «webEvento». ===== */
  const SITIO = /^\/b2b\//.test(location.pathname) ? "b2b" : "web", PAG = (location.pathname.replace(/\/index\.html$/, "/") || "/").slice(0, 80), COLA = [];
  const ses = (() => { try { let x = sessionStorage.getItem("hwf_ses"); if (!x) { x = Math.random().toString(36).slice(2, 10); sessionStorage.setItem("hwf_ses", x); } return x; } catch (e) { return "s" + Math.random().toString(36).slice(2, 8); } })();
  const t0 = Date.now(); let visible = Date.now(), activo = 0, lectura = 0, enviadoFin = false;
  function ev(tipo, detalle, valor) { if (!E || !E.analitica) { if (!E) COLA.push([tipo, PAG, String(detalle || "").slice(0, 80), Number(valor) || 0]); return; }
    COLA.push([tipo, PAG, String(detalle || "").slice(0, 80), Number(valor) || 0]); if (COLA.length >= 20) enviar(); }
  function enviar(fin) { if (!E || !E.analitica || !COLA.length) return; const L = COLA.splice(0, 40);
    const d = { accion: "webEvento", s: SITIO, ses, vis: E.id, d: /Mobi|Android|iPhone/i.test(navigator.userAgent) ? "m" : "p", ev: L };
    try { const t = typeof window.HWF_EV_T === "function" ? window.HWF_EV_T() : ""; if (t) d.t = t; } catch (e) {}
    try { _f("/b2b/api.php", { method: "POST", headers: { "Content-Type": "application/json" }, keepalive: true, body: JSON.stringify(d) }).catch(() => {}); } catch (e) {} }
  const CTA = [[/wa\.me|whatsapp/i, "WhatsApp"], [/^tel:/i, "Llamar"], [/^mailto:/i, "Correo"], [/instagram\.com/i, "Instagram"], [/linkedin\.com/i, "LinkedIn"], [/\/b2b\/?(#.*)?$/i, "Acceso Clientes"], [/\/trabaja\//i, "Trabaja con nosotros"], [/\/kit\//i, "Kit para tu local"], [/#catalogo/i, "Ver catálogo"], [/\/marcas\//i, "Página de marca"], [/\/categorias\//i, "Página de categoría"]];
  document.addEventListener("click", e => { const a = e.target.closest("a,button"); if (!a || a.closest("#hwfCk")) return;
    const k = a.getAttribute("data-ev"); if (k) return ev("clic", k);
    const h = a.getAttribute("href") || a.getAttribute("data-wa") != null && "whatsapp" || ""; for (const [re, n] of CTA) if (re.test(h)) return ev("clic", n + (a.dataset.wa != null && /precio/i.test(a.dataset.wa) ? " · pedir precios" : "")); }, true);
  addEventListener("scroll", () => { const h = document.documentElement, p = Math.round((h.scrollTop + innerHeight) / Math.max(1, h.scrollHeight) * 100); if (p > lectura) lectura = Math.min(100, p); }, { passive: true });
  document.addEventListener("visibilitychange", () => { if (document.hidden) { activo += Date.now() - visible; fin(); } else { visible = Date.now(); enviadoFin = false; } });
  addEventListener("pagehide", () => { if (!document.hidden) activo += Date.now() - visible; fin(); });
  function fin() { if (enviadoFin) return; enviadoFin = true; const sg = Math.round(activo / 1000); if (sg >= 1) ev("tiempo", "", Math.min(sg, 3600)); if (SITIO === "web") ev("lectura", "", lectura || 0); activo = 0; enviar(true); }
  ev("pagina", document.title.slice(0, 80));
  setInterval(() => enviar(), 15000);
  window.hwfCookies = { estado: () => E, abrir: () => abrir(true), evento: ev, cuando(cat, fn) { if (E && E[cat]) { try { fn(); } catch (e) {} } else (subs[cat] || []).push(fn); } };
  const iniciar = () => { document.addEventListener("click", e => { const a = e.target.closest("[data-cookies]"); if (a) { e.preventDefault(); abrir(true); } });
    if (!E) abrir(false); };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();
