/* «claudIA», la asistente IA de HWF (24-11-2026): chat flotante para hwf.cl y el portal B2B; con data-marca="tienda" en la etiqueta
   <script src="/agente.js" data-marca="tienda"> es la claudIA de la Tienda Hellywoof (cliente final, cercana). Habla con /b2b/api.php (acción «agente»).
   Sin sesión: visitante (catálogo sin precios, nutrición, deja sus datos). Con la sesión del portal (hwfb2b_token): cliente (sus precios,
   deuda, pedidos y propuestas de pedido que se agregan al carrito; el pedido lo envía el cliente desde el carrito).
   Historial solo en esta pestaña (sessionStorage). Sin cookies. */
(function () {
  if (window.__hwfAgente) return; window.__hwfAgente = 1;
  const ME = document.currentScript, MARCA = ME && ME.dataset.marca === "tienda" ? "tienda" : "distribuidora", TDA = MARCA === "tienda";
  const API = (ME && ME.dataset.api) || "/b2b/api.php", SK = "hwf-agente-hist-" + MARCA, PORTAL = !TDA && /\/b2b\/?/.test(location.pathname);
  const ss = (k, v) => { try { if (v === undefined) return sessionStorage.getItem(k); sessionStorage.setItem(k, v); } catch (e) { return null; } };
  const tok = () => { if (TDA) return ""; try { const t = localStorage.getItem("hwfb2b_token") || ""; return /^[0-9a-f]{64}$/.test(t) ? t : ""; } catch (e) { return ""; } };
  const es = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const md = s => es(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/(https?:\/\/[^\s<]+|hwf\.cl\/[a-z0-9/]*)/gi, m => `<a href="${/^http/.test(m) ? m : "https://www." + m}" target="_blank" rel="noopener">${m}</a>`).replace(/\n/g, "<br>");
  const $p = n => "$" + Math.round(Number(n) || 0).toLocaleString("es-CL");
  let H = []; try { H = JSON.parse(ss(SK) || "[]"); } catch (e) { H = []; }
  const CSS = `#hwfAg{position:fixed;left:14px;bottom:14px;z-index:2147482000;font-family:inherit}#hwfAgB{display:flex;align-items:center;gap:8px;border:0;border-radius:999px;background:#0B3147;color:#fff;padding:11px 16px 11px 12px;font:700 14px/1 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;box-shadow:0 10px 28px rgba(11,49,71,.32);cursor:pointer}
#hwfAgB i{width:28px;height:28px;border-radius:50%;background:#80C6C9;display:grid;place-items:center;font-style:normal;font-size:16px}
#hwfAgP{position:fixed;left:14px;bottom:76px;width:min(380px,calc(100vw - 28px));height:min(560px,calc(100vh - 110px));background:#fff;color:#0F1E29;border-radius:20px;box-shadow:0 20px 60px rgba(11,49,71,.3);display:flex;flex-direction:column;overflow:hidden;border:1px solid #DAE1E7}
#hwfAgP[hidden]{display:none}#hwfAgP header{background:linear-gradient(120deg,#0B3147,#1D5A78);color:#fff;padding:12px 14px;display:flex;align-items:center;gap:10px}#hwfAgP header b{font-size:15px}#hwfAgP header small{display:block;opacity:.8;font-size:12px;font-weight:500}
#hwfAgP header button{margin-left:auto;border:0;background:rgba(255,255,255,.15);color:#fff;width:32px;height:32px;border-radius:50%;cursor:pointer;font-size:18px}
#hwfAgL{flex:1;overflow:auto;padding:12px;display:flex;flex-direction:column;gap:8px;background:#F4F8FA;font:14px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
.agm{max-width:88%;padding:9px 12px;border-radius:14px;white-space:normal;word-wrap:break-word}.agm.u{align-self:flex-end;background:#0B3147;color:#fff;border-bottom-right-radius:4px}.agm.a{align-self:flex-start;background:#fff;border:1px solid #E3E9EE;border-bottom-left-radius:4px}.agm a{color:#1D5A78;font-weight:700}
.agm.e{align-self:center;background:#FDECEA;color:#B3261E;font-size:13px}.agq{display:flex;flex-wrap:wrap;gap:6px}.agq button{border:1px solid #CFDDE4;background:#fff;color:#0B3147;border-radius:999px;padding:6px 11px;font:600 12.5px system-ui,sans-serif;cursor:pointer}
.agp{align-self:stretch;background:#fff;border:2px solid #80C6C9;border-radius:14px;padding:10px 12px;font-size:13px}.agp table{width:100%;border-collapse:collapse}.agp td{padding:3px 0;border-bottom:1px solid #EEF2F5}.agp td:last-child{text-align:right;white-space:nowrap}
.agp .t{display:flex;justify-content:space-between;font-weight:800;margin-top:6px}.agp button{margin-top:8px;width:100%;border:0;border-radius:10px;background:#0B3147;color:#fff;padding:10px;font:800 14px system-ui,sans-serif;cursor:pointer}
#hwfAgF{display:flex;gap:6px;padding:10px;border-top:1px solid #E3E9EE;background:#fff}#hwfAgF textarea{flex:1;resize:none;border:1.5px solid #CFDDE4;border-radius:12px;padding:9px 10px;font:14px system-ui,sans-serif;height:42px;max-height:110px;color:#0F1E29;background:#fff}
#hwfAgF button{border:0;border-radius:12px;background:#80C6C9;color:#0B3147;font:900 15px system-ui,sans-serif;padding:0 14px;cursor:pointer}#hwfAgF button:disabled{opacity:.5}
.agw{align-self:flex-start;color:#5B6874;font-size:13px}.agw:after{content:"…";animation:agd 1s steps(3) infinite}@keyframes agd{0%{content:"."}50%{content:".."}100%{content:"..."}}
@media(max-width:700px){#hwfAg{bottom:92px}#hwfAgP{bottom:150px;height:min(520px,calc(100vh - 170px))}#hwfAgB span{display:none}#hwfAgB{padding:11px}}
@media print{#hwfAg{display:none}}`;
  const st = document.createElement("style"); st.textContent = CSS; document.head.appendChild(st);
  const W = document.createElement("div"); W.id = "hwfAg";
  W.innerHTML = `<div id="hwfAgP" hidden role="dialog" aria-label="Asistente IA de HWF"><header><div><b>claudIA · asistente IA</b><small id="hwfAgS">${TDA ? "Tienda Hellywoof 🐾" : "HWF Distribuidora"}</small></div><button type="button" id="hwfAgX" aria-label="Cerrar">×</button></header>
    <div id="hwfAgL" aria-live="polite"></div><form id="hwfAgF"><textarea id="hwfAgT" rows="1" maxlength="1500" placeholder="Escribe tu consulta…" aria-label="Mensaje"></textarea><button type="submit" aria-label="Enviar">➤</button></form></div>
    <button type="button" id="hwfAgB" aria-expanded="false" aria-controls="hwfAgP"><i aria-hidden="true">🐾</i><span>Pregúntale a claudIA</span></button>`;
  document.body.appendChild(W);
  const L = W.querySelector("#hwfAgL"), T = W.querySelector("#hwfAgT"), P = W.querySelector("#hwfAgP"), B = W.querySelector("#hwfAgB");
  const SUG = () => TDA ? ["Busco alimento para mi cachorro", "Mi gato está esterilizado, ¿qué le doy?", "¿Tienen arena sin olor?", "Quiero reservar un producto"] : tok() ? ["¿Cuánto debo?", "Mis últimos pedidos", "Arma mi pedido de siempre", "¿Qué hay para gato urinario?"] : ["¿Qué marcas trabajan?", "Compara mi alimento con uno de HWF", "¿Despachan a mi comuna?", "Quiero ser cliente"];
  function pintar(cargando) {
    L.innerHTML = (H.length ? "" : `<div class="agm a">${TDA ? "¡Hola! 🐾 Soy <b>claudIA</b>, de la Tienda Hellywoof. Cuéntame de tu regalón o regalona y te ayudo a encontrar lo que necesita." : "Hola 👋 Soy <b>claudIA</b>, la asistente IA de HWF. " + (tok() ? "Te reconozco por tu sesión del portal: puedo ver tus precios, tu cuenta y armar tu pedido." : "Te ayudo con el catálogo, la nutrición de cada alimento y cómo ser cliente.")}</div><div class="agq">${SUG().map(s => `<button type="button">${es(s)}</button>`).join("")}</div>`)
      + H.map(m => m.role === "user" ? `<div class="agm u">${es(m.content)}</div>` : m.role === "error" ? `<div class="agm e">${es(m.content)}</div>` : `<div class="agm a">${md(m.content)}</div>${m.prop ? propHtml(m.prop) : ""}`).join("") + (cargando ? `<div class="agw">claudIA está escribiendo</div>` : "");
    L.querySelectorAll(".agq button").forEach(b => b.onclick = () => enviar(b.textContent));
    L.querySelectorAll("[data-agc]").forEach(b => b.onclick = () => alCarro(H[+b.dataset.agc].prop, b));
    L.scrollTop = L.scrollHeight;
  }
  function propHtml(p) { const i = H.findIndex(m => m.prop === p);
    return `<div class="agp"><b>Propuesta de pedido</b><table>${p.items.map(x => `<tr><td>${es(x.d)} <small>×${x.q}</small></td><td>${$p(x.v)}</td></tr>`).join("")}</table>
      <div class="t"><span>Neto</span><span>${$p(p.neto)} + IVA</span></div><small>Total con IVA ${$p(p.total)}. Aún no está enviado.</small><button type="button" data-agc="${i}">${PORTAL ? "Agregar al carrito y revisar" : "Abrir en el portal y revisar"}</button></div>`; }
  function alCarro(p, b) { if (!p) return;
    if (window.hwfB2B && window.hwfB2B.agregar) { window.hwfB2B.agregar(p.items.map(x => ({ i: x.i, q: x.q })), p.obs); b.textContent = "✓ En tu carrito: revisa y envía"; return; }
    try { const c = JSON.parse(localStorage.getItem("hwfb2b_carro") || "{}"); p.items.forEach(x => c[x.i] = (Number(c[x.i]) || 0) + x.q); localStorage.setItem("hwfb2b_carro", JSON.stringify(c)); } catch (e) {}
    location.href = "/b2b/"; }
  let ocupado = false;
  async function enviar(txt) { txt = String(txt || "").trim(); if (!txt || ocupado) return; ocupado = true; W.querySelector("#hwfAgF button").disabled = true;
    const hist = H.filter(m => m.role === "user" || m.role === "assistant").slice(-10).map(m => ({ role: m.role, content: m.content }));
    H.push({ role: "user", content: txt }); pintar(true);
    try { const r = await fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ accion: "agente", marca: MARCA, texto: txt, historial: hist }, tok() ? { token: tok() } : {})) });
      const j = await r.json().catch(() => ({}));
      if (j && j.ok) H.push({ role: "assistant", content: j.respuesta || "", prop: j.propuesta || null }); else H.push({ role: "error", content: (j && (j.error || j.mensaje)) || "No pude responder. Escríbenos por WhatsApp al +56 9 6606 3522." });
    } catch (e) { H.push({ role: "error", content: "Sin conexión. Intenta de nuevo." }); }
    H = H.slice(-30); ss(SK, JSON.stringify(H)); ocupado = false; W.querySelector("#hwfAgF button").disabled = false; pintar(false);
    try { window.hwfCookies && window.hwfCookies.evento && window.hwfCookies.evento("agente", { rol: TDA ? "tienda" : tok() ? "cliente" : "publico" }); } catch (e) {} }
  const abrir = on => { P.hidden = !on; B.setAttribute("aria-expanded", on); if (on) { pintar(false); setTimeout(() => T.focus(), 50); } };
  B.onclick = () => abrir(P.hidden); W.querySelector("#hwfAgX").onclick = () => abrir(false);
  W.querySelector("#hwfAgF").onsubmit = e => { e.preventDefault(); const v = T.value; T.value = ""; enviar(v); };
  T.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); W.querySelector("#hwfAgF").requestSubmit(); } });
  document.addEventListener("keydown", e => { if (e.key === "Escape" && !P.hidden) abrir(false); });
})();
