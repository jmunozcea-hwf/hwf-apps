<?php
/*
 * Webhook de WhatsApp (Meta WhatsApp Cloud API) para el asistente IA «Hugo» de HWF (24-11-2026).
 * GET  → verificación del webhook (hub.verify_token).
 * POST → mensajes entrantes: se valida la firma X-Hub-Signature-256 con el App Secret, se responde 200 de inmediato y luego
 *        se pasa el texto al script de Google (acción «agente», origen «whatsapp», teléfono del remitente) y se contesta por WhatsApp.
 * El ROL (visitante, cliente B2B o equipo HWF) lo decide el script según el teléfono, no el mensaje.
 * Configuración en config.php (nunca en el repositorio): wa_token, wa_phone_id, wa_verify, wa_app_secret (+ script_url y clave).
 */
declare(strict_types=1);
const WA_MAX = 65536;
const WA_GRAPH = 'https://graph.facebook.com/v21.0/';

function wa_cfg(): ?array {
    $f = __DIR__ . '/config.php';
    if (!is_file($f)) { return null; }
    $c = require $f;
    foreach (['script_url', 'clave', 'wa_token', 'wa_phone_id', 'wa_verify', 'wa_app_secret'] as $k) {
        if (!is_array($c) || !isset($c[$k]) || !is_string($c[$k]) || $c[$k] === '') { return null; }
    }
    return $c;
}
function wa_post(string $url, string $json, array $hdr, int $timeout): ?string {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => $json, CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => $timeout, CURLOPT_HTTPHEADER => array_merge(['Content-Type: application/json'], $hdr)]);
    $r = curl_exec($ch);
    $ok = $r !== false && curl_getinfo($ch, CURLINFO_RESPONSE_CODE) < 500;
    curl_close($ch);
    return $ok ? (string)$r : null;
}
/* una sola vez por id de mensaje (Meta reintenta): archivo temporal con los últimos 500 ids */
function wa_nuevo(string $id): bool {
    $ruta = rtrim(sys_get_temp_dir(), '/') . '/hwf_wa_ids.json';
    $f = @fopen($ruta, 'c+'); if ($f === false || !flock($f, LOCK_EX)) { return true; }
    $L = json_decode((string)stream_get_contents($f), true); if (!is_array($L)) { $L = []; }
    $nuevo = !in_array($id, $L, true);
    if ($nuevo) { $L[] = $id; $L = array_slice($L, -500); ftruncate($f, 0); rewind($f); fwrite($f, json_encode($L)); }
    flock($f, LOCK_UN); fclose($f);
    return $nuevo;
}
function wa_enviar(array $c, string $a, string $texto): void {
    foreach (str_split($texto, 3900) as $parte) {   // WhatsApp admite hasta 4096 caracteres por mensaje
        wa_post(WA_GRAPH . rawurlencode($c['wa_phone_id']) . '/messages',
            (string)json_encode(['messaging_product' => 'whatsapp', 'to' => $a, 'type' => 'text', 'text' => ['body' => $parte, 'preview_url' => false]], JSON_UNESCAPED_UNICODE),
            ['Authorization: Bearer ' . $c['wa_token']], 20);
    }
}

$cfg = wa_cfg();
if ($cfg === null) { http_response_code(503); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'GET') {   // verificación del webhook en Meta
    if (($_GET['hub_mode'] ?? '') === 'subscribe' && hash_equals($cfg['wa_verify'], (string)($_GET['hub_verify_token'] ?? ''))) {
        header('Content-Type: text/plain'); echo preg_replace('/[^0-9A-Za-z_-]/', '', (string)($_GET['hub_challenge'] ?? '')); exit;
    }
    http_response_code(403); exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$raw = file_get_contents('php://input', false, null, 0, WA_MAX + 1);
if (!is_string($raw) || strlen($raw) > WA_MAX) { http_response_code(413); exit; }
$firma = (string)($_SERVER['HTTP_X_HUB_SIGNATURE_256'] ?? '');
if (!hash_equals('sha256=' . hash_hmac('sha256', $raw, $cfg['wa_app_secret']), $firma)) { http_response_code(401); exit; }

$d = json_decode($raw, true);
$mensajes = [];
foreach ((array)($d['entry'] ?? []) as $e) {
    foreach ((array)($e['changes'] ?? []) as $ch) {
        foreach ((array)($ch['value']['messages'] ?? []) as $m) {
            if (!is_array($m) || !isset($m['id'], $m['from'])) { continue; }
            $t = ($m['type'] ?? '') === 'text' ? (string)($m['text']['body'] ?? '') : '';
            $mensajes[] = ['id' => (string)$m['id'], 'from' => preg_replace('/\D/', '', (string)$m['from']), 'texto' => mb_substr($t, 0, 1500)];
        }
    }
}
// responder 200 a Meta de inmediato; el agente puede tardar varios segundos
http_response_code(200); header('Content-Type: text/plain'); echo 'ok';
if (function_exists('fastcgi_finish_request')) { fastcgi_finish_request(); } else { @ob_end_flush(); @flush(); }
ignore_user_abort(true); set_time_limit(120);

foreach ($mensajes as $m) {
    if ($m['from'] === '' || !wa_nuevo($m['id'])) { continue; }
    if ($m['texto'] === '') { wa_enviar($cfg, $m['from'], 'Por ahora solo leo mensajes de texto. Escríbeme tu consulta 🙂'); continue; }
    $r = wa_post($cfg['script_url'], (string)json_encode(['accion' => 'agente', 'origen' => 'whatsapp', 'wa_from' => $m['from'], 'texto' => $m['texto'], 'clave' => $cfg['clave']], JSON_UNESCAPED_UNICODE), [], 90);
    $j = $r === null ? null : json_decode($r, true);
    $resp = is_array($j) ? (string)($j['respuesta'] ?? ($j['error'] ?? '')) : '';
    wa_enviar($cfg, $m['from'], $resp !== '' ? $resp : 'Tuve un problema para responder. Escríbenos al +56 9 6606 3522 y te atendemos.');
}
